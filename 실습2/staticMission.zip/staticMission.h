#pragma once

void libInfo();

int GCD(int a, int b);

int LCM(int a, int b);